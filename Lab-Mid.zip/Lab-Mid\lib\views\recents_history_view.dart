import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/document_provider.dart';
import '../providers/reader_provider.dart';
import '../widgets/empty_state_widget.dart';
import '../widgets/reading_progress_bar.dart';
import 'pdf_reader_view.dart';

class RecentsHistoryView extends StatefulWidget {
  const RecentsHistoryView({Key? key}) : super(key: key);

  @override
  State<RecentsHistoryView> createState() => _RecentsHistoryViewState();
}

class _RecentsHistoryViewState extends State<RecentsHistoryView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ReaderProvider>().loadReadingHistory();
    });
  }

  void _resumeReading(BuildContext context, int docId, int lastPage) {
    final docProvider = context.read<DocumentProvider>();
    final matches = docProvider.documents.where((d) => d.id == docId);

    if (matches.isNotEmpty) {
      final doc = matches.first;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => PdfReaderView(
            document: doc,
            initialPage: lastPage,
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Document no longer exists in library')),
      );
    }
  }

  void _confirmClearHistory(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear Reading History?'),
        content: const Text('This will clear your recent reading logs. Your documents and bookmarks will remain intact.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              context.read<ReaderProvider>().clearHistory();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final readerProvider = context.watch<ReaderProvider>();
    final historyList = readerProvider.readingHistory;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Reading History & Recents'),
        actions: [
          if (historyList.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_sweep_outlined),
              tooltip: 'Clear History',
              onPressed: () => _confirmClearHistory(context),
            ),
        ],
      ),
      body: historyList.isEmpty
          ? const EmptyStateWidget(
              icon: Icons.history_rounded,
              title: 'No Reading History',
              message: 'When you open and read documents, your reading progress and last-read pages will be recorded here so you can easily resume reading.',
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // Analytical Banner
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [theme.colorScheme.primary, theme.colorScheme.primary.withOpacity(0.8)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: theme.colorScheme.primary.withOpacity(0.25),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildHeaderMetric('Total Sessions', '${historyList.length}', Icons.auto_stories_rounded),
                      Container(width: 1, height: 40, color: Colors.white24),
                      _buildHeaderMetric(
                        'Recent Activity',
                        DateFormat('h:mm a').format(historyList.first.timestamp),
                        Icons.access_time_rounded,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                Text(
                  'Reading Timeline',
                  style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 12),

                // History Items
                ...historyList.map((item) {
                  final timeFormatted = DateFormat('MMM d, yyyy • h:mm a').format(item.timestamp);
                  final isDone = item.progressPercentage >= 0.99;

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                radius: 18,
                                backgroundColor: isDone
                                    ? Colors.green.shade50
                                    : theme.colorScheme.primary.withOpacity(0.1),
                                child: Icon(
                                  isDone ? Icons.check_circle : Icons.book_outlined,
                                  size: 18,
                                  color: isDone ? Colors.green : theme.colorScheme.primary,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item.documentTitle,
                                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      timeFormatted,
                                      style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                                    ),
                                  ],
                                ),
                              ),
                              ElevatedButton.icon(
                                onPressed: () => _resumeReading(context, item.documentId, item.pageNumber),
                                icon: const Icon(Icons.play_arrow_rounded, size: 16),
                                label: const Text('Resume', style: TextStyle(fontSize: 12)),
                                style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                  visualDensity: VisualDensity.compact,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          ReadingProgressBar(
                            progress: item.progressPercentage,
                            showText: true,
                            height: 5,
                          ),
                          const SizedBox(height: 6),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Stopped at Page ${item.pageNumber} of ${item.totalPages}',
                                style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                              ),
                              Text(
                                item.formattedProgress,
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  color: isDone ? Colors.green : theme.colorScheme.primary,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ],
            ),
    );
  }

  Widget _buildHeaderMetric(String label, String value, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 24),
        const SizedBox(height: 6),
        Text(
          value,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        Text(
          label,
          style: const TextStyle(fontSize: 11, color: Colors.white70),
        ),
      ],
    );
  }
}
