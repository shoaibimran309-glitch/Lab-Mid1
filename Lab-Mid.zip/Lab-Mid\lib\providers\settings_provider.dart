import 'package:flutter/material.dart';
import '../models/user_preferences_model.dart';
import '../database/db_helper.dart';
import '../services/notification_service.dart';

class SettingsProvider extends ChangeNotifier {
  UserPreferencesModel _preferences = UserPreferencesModel();
  bool _isLoaded = false;

  UserPreferencesModel get preferences => _preferences;
  ThemeMode get themeMode => _preferences.themeMode;
  Color get readingBgColor => _preferences.readingBgColor;
  int get readingBgColorValue => _preferences.readingBgColorValue;
  String get notificationSound => _preferences.notificationSound;
  int get dailyGoalMinutes => _preferences.dailyGoalMinutes;
  String get reminderTime => _preferences.reminderTime;
  bool get remindersEnabled => _preferences.remindersEnabled;
  bool get isLoaded => _isLoaded;

  /// Load user preferences from SQLite
  Future<void> loadPreferences() async {
    final prefsMap = await DatabaseHelper.instance.getAllPreferences();
    if (prefsMap.isNotEmpty) {
      _preferences = UserPreferencesModel.fromMap(prefsMap);
    }
    _isLoaded = true;
    notifyListeners();
  }

  /// Change theme mode (Light, Dark, System)
  Future<void> setThemeMode(ThemeMode mode) async {
    _preferences = _preferences.copyWith(themeMode: mode);
    await DatabaseHelper.instance.savePreference('theme_mode', mode.name);
    notifyListeners();
  }

  /// Change reading background color
  Future<void> setReadingBgColor(int colorValue) async {
    _preferences = _preferences.copyWith(readingBgColorValue: colorValue);
    await DatabaseHelper.instance.savePreference('reading_bg_color', colorValue.toString());
    notifyListeners();
  }

  /// Change notification sound preference
  Future<void> setNotificationSound(String sound) async {
    _preferences = _preferences.copyWith(notificationSound: sound);
    await DatabaseHelper.instance.savePreference('notification_sound', sound);
    notifyListeners();
  }

  /// Update daily reading goal
  Future<void> setDailyGoalMinutes(int minutes) async {
    _preferences = _preferences.copyWith(dailyGoalMinutes: minutes);
    await DatabaseHelper.instance.savePreference('daily_goal_minutes', minutes.toString());
    notifyListeners();
  }

  /// Update reminder time and schedule notification
  Future<void> setReminderTime(String time) async {
    _preferences = _preferences.copyWith(reminderTime: time);
    await DatabaseHelper.instance.savePreference('reminder_time', time);

    if (_preferences.remindersEnabled) {
      final parts = time.split(':');
      if (parts.length == 2) {
        final hour = int.tryParse(parts[0]) ?? 20;
        final minute = int.tryParse(parts[1]) ?? 0;
        await NotificationService.instance.scheduleReadingSession(
          hour: hour,
          minute: minute,
          goalMinutes: _preferences.dailyGoalMinutes,
        );
      }
    }
    notifyListeners();
  }

  /// Toggle reminders enabled/disabled
  Future<void> setRemindersEnabled(bool enabled) async {
    _preferences = _preferences.copyWith(remindersEnabled: enabled);
    await DatabaseHelper.instance.savePreference('reminders_enabled', enabled ? '1' : '0');

    if (enabled) {
      final parts = _preferences.reminderTime.split(':');
      final hour = parts.length == 2 ? int.tryParse(parts[0]) ?? 20 : 20;
      final minute = parts.length == 2 ? int.tryParse(parts[1]) ?? 0 : 0;
      await NotificationService.instance.scheduleReadingSession(
        hour: hour,
        minute: minute,
        goalMinutes: _preferences.dailyGoalMinutes,
      );
    } else {
      await NotificationService.instance.cancelAll();
    }
    notifyListeners();
  }

  /// Trigger test notification
  Future<void> triggerTestNotification() async {
    await NotificationService.instance.showReadingGoalReminder(_preferences.dailyGoalMinutes);
  }
}
