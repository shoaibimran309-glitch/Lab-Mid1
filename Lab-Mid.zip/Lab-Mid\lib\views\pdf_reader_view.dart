import 'dart:io';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import 'package:provider/provider.dart';
import '../models/document_model.dart';
import '../providers/document_provider.dart';
import '../providers/reader_provider.dart';
import '../providers/settings_provider.dart';
import '../utils/constants.dart';
import 'pdf_to_image_view.dart';

class PdfReaderView extends StatefulWidget {
  final DocumentModel document;
  final int? initialPage;

  const PdfReaderView({
    Key? key,
    required this.document,
    this.initialPage,
  }) : super(key: key);

  @override
  State<PdfReaderView> createState() => _PdfReaderViewState();
}

class _PdfReaderViewState extends State<PdfReaderView> {
  late PdfViewerController _pdfViewerController;
  int _currentPage = 1;
  int _pageCount = 1;
  late int _activeBgColorValue;

  @override
  void initState() {
    super.initState();
    _pdfViewerController = PdfViewerController();
    _currentPage = widget.initialPage ?? widget.document.lastReadPage;
    _pageCount = widget.document.pageCount > 0 ? widget.document.pageCount : 1;

    final settings = context.read<SettingsProvider>();
    _activeBgColorValue = settings.readingBgColorValue;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final reader = context.read<ReaderProvider>();
      reader.openDocument(widget.document);

      // Jump to last read page once controller is ready
      if (_currentPage > 1) {
        _pdfViewerController.jumpToPage(_currentPage);
      }
    });
  }

  @override
  void dispose() {
    _pdfViewerController.dispose();
    super.dispose();
  }

  void _onPageChanged(PdfPageChangedDetails details) {
    setState(() {
      _currentPage = details.newPageNumber;
      _pageCount = _pdfViewerController.pageCount > 0
          ? _pdfViewerController.pageCount
          : widget.document.pageCount;
    });

    context.read<ReaderProvider>().onPageChanged(_currentPage, _pageCount);
  }

  void _onDocumentLoaded(PdfDocumentLoadedDetails details) {
    setState(() {
      _pageCount = details.document.pages.count;
    });

    if (widget.initialPage != null && widget.initialPage! > 1) {
      _pdfViewerController.jumpToPage(widget.initialPage!);
    } else if (widget.document.lastReadPage > 1) {
      _pdfViewerController.jumpToPage(widget.document.lastReadPage);
    }
  }

  void _showJumpToPageDialog() {
    final controller = TextEditingController(text: '$_currentPage');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Jump to Page'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Enter page number between 1 and $_pageCount:'),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              autofocus: true,
              decoration: InputDecoration(
                hintText: '1 - $_pageCount',
                prefixIcon: const Icon(Icons.pin_rounded),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final page = int.tryParse(controller.text);
              if (page != null && page >= 1 && page <= _pageCount) {
                Navigator.of(ctx).pop();
                _pdfViewerController.jumpToPage(page);
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Please enter a valid page number (1-$_pageCount)')),
                );
              }
            },
            child: const Text('Jump'),
          ),
        ],
      ),
    );
  }

  void _toggleBookmarkWithDialog() {
    final reader = context.read<ReaderProvider>();
    final isBookmarked = reader.isPageBookmarked(_currentPage);

    if (isBookmarked) {
      reader.toggleBookmarkCurrentPage();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Removed bookmark from Page $_currentPage')),
      );
    } else {
      final noteController = TextEditingController();
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('Bookmark Page $_currentPage'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Add an optional note for this bookmark:'),
              const SizedBox(height: 10),
              TextField(
                controller: noteController,
                autofocus: true,
                decoration: const InputDecoration(
                  hintText: 'e.g. Important formula / Exam question',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(ctx).pop();
                reader.toggleBookmarkCurrentPage(note: noteController.text.trim());
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Bookmarked Page $_currentPage')),
                );
              },
              child: const Text('Save Bookmark'),
            ),
          ],
        ),
      );
    }
  }

  void _showBookmarksBottomSheet() {
    final reader = context.read<ReaderProvider>();
    final bookmarks = reader.documentBookmarks;

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Bookmarks (${bookmarks.length})',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.of(ctx).pop(),
                    ),
                  ],
                ),
              ),
              const Divider(),
              if (bookmarks.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(
                    child: Text('No bookmarks added for this document yet.'),
                  ),
                )
              else
                Expanded(
                  child: ListView.builder(
                    itemCount: bookmarks.length,
                    itemBuilder: (context, idx) {
                      final bm = bookmarks[idx];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                          child: Text(
                            '${bm.pageNumber}',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          ),
                        ),
                        title: Text('Page ${bm.pageNumber}'),
                        subtitle: Text(bm.note.isNotEmpty ? bm.note : 'No note'),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.redAccent, size: 20),
                          onPressed: () {
                            if (bm.id != null) {
                              reader.deleteBookmark(bm.id!);
                              Navigator.of(ctx).pop();
                            }
                          },
                        ),
                        onTap: () {
                          Navigator.of(ctx).pop();
                          _pdfViewerController.jumpToPage(bm.pageNumber);
                        },
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _showBgColorPicker() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Reading Background Tint',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              const Text(
                'Select a comfortable background tint for eye-friendly reading:',
                style: TextStyle(color: Colors.grey, fontSize: 13),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: AppConstants.readingBgColors.map((item) {
                  final isSelected = _activeBgColorValue == item.value;
                  return GestureDetector(
                    onTap: () {
                      setState(() => _activeBgColorValue = item.value);
                      context.read<SettingsProvider>().setReadingBgColor(item.value);
                      Navigator.of(ctx).pop();
                    },
                    child: Column(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: item.color,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: isSelected ? Colors.blue : Colors.grey.shade400,
                              width: isSelected ? 3 : 1,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 4,
                              ),
                            ],
                          ),
                          child: isSelected
                              ? Icon(Icons.check, color: item.textColor, size: 22)
                              : null,
                        ),
                        const SizedBox(height: 6),
                        Text(
                          item.name.split(' ').first,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final reader = context.watch<ReaderProvider>();
    final docProvider = context.watch<DocumentProvider>();
    final isPageBookmarked = reader.isPageBookmarked(_currentPage);
    final isFavorite = widget.document.isFavorite;
    final progressPct = ((_currentPage / (_pageCount > 0 ? _pageCount : 1)) * 100).toInt();

    final bgColor = Color(_activeBgColorValue);
    final isDarkTint = _activeBgColorValue == 0xFF1E1E1E;

    final file = File(widget.document.filePath);
    final fileExists = file.existsSync();

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: isDarkTint ? const Color(0xFF1E1E1E) : null,
        foregroundColor: isDarkTint ? Colors.white : null,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.document.title,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              'Page $_currentPage of $_pageCount ($progressPct%)',
              style: TextStyle(
                fontSize: 11,
                color: isDarkTint ? Colors.white70 : Colors.grey.shade600,
              ),
            ),
          ],
        ),
        actions: [
          // Favorite Button
          IconButton(
            icon: Icon(
              isFavorite ? Icons.favorite : Icons.favorite_border,
              color: isFavorite ? Colors.red : null,
            ),
            tooltip: 'Favorite',
            onPressed: () => docProvider.toggleFavorite(widget.document),
          ),
          // Bookmark Current Page
          IconButton(
            icon: Icon(
              isPageBookmarked ? Icons.bookmark : Icons.bookmark_border,
              color: isPageBookmarked ? Colors.amber.shade700 : null,
            ),
            tooltip: isPageBookmarked ? 'Remove Bookmark' : 'Bookmark Page',
            onPressed: _toggleBookmarkWithDialog,
          ),
          // Bookmarks List Drawer
          IconButton(
            icon: const Icon(Icons.bookmarks_outlined),
            tooltip: 'View Bookmarks',
            onPressed: _showBookmarksBottomSheet,
          ),
          // Reading Background Color
          IconButton(
            icon: const Icon(Icons.color_lens_outlined),
            tooltip: 'Reading Tint',
            onPressed: _showBgColorPicker,
          ),
          // More Tools Menu
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert),
            onSelected: (val) {
              if (val == 'jump') _showJumpToPageDialog();
              if (val == 'convert') {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => PdfToImageView(
                      selectedDocument: widget.document,
                      initialPage: _currentPage,
                    ),
                  ),
                );
              }
            },
            itemBuilder: (ctx) => [
              const PopupMenuItem(
                value: 'jump',
                child: Row(
                  children: [
                    Icon(Icons.pin_rounded, size: 18),
                    SizedBox(width: 8),
                    Text('Jump to Page...'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'convert',
                child: Row(
                  children: [
                    Icon(Icons.image_outlined, size: 18),
                    SizedBox(width: 8),
                    Text('Convert Page to Image'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: !fileExists
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, size: 64, color: Colors.red),
                    const SizedBox(height: 16),
                    Text(
                      'PDF File Not Found',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: isDarkTint ? Colors.white : Colors.black,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Path: ${widget.document.filePath}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ],
                ),
              ),
            )
          : Stack(
              children: [
                // SfPdfViewer Engine
                Container(
                  color: bgColor,
                  child: SfPdfViewer.file(
                    file,
                    controller: _pdfViewerController,
                    canShowScrollHead: true,
                    canShowScrollStatus: true,
                    enableDoubleTapZooming: true,
                    onPageChanged: _onPageChanged,
                    onDocumentLoaded: _onDocumentLoaded,
                  ),
                ),
                // Tint overlay for custom reading background color when not white
                if (_activeBgColorValue != 0xFFFFFFFF)
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Container(
                        color: bgColor.withOpacity(isDarkTint ? 0.35 : 0.18),
                      ),
                    ),
                  ),
              ],
            ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: isDarkTint ? const Color(0xFF1E1E1E) : Theme.of(context).cardColor,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.08),
                blurRadius: 8,
                offset: const Offset(0, -2),
              ),
            ],
          ),
          child: Row(
            children: [
              // Previous Page
              IconButton(
                icon: const Icon(Icons.arrow_back_ios_rounded, size: 18),
                tooltip: 'Previous Page',
                onPressed: _currentPage > 1
                    ? () => _pdfViewerController.previousPage()
                    : null,
              ),

              // Page Slider
              Expanded(
                child: Slider(
                  value: _currentPage.toDouble().clamp(1.0, _pageCount.toDouble()),
                  min: 1.0,
                  max: _pageCount > 0 ? _pageCount.toDouble() : 1.0,
                  divisions: _pageCount > 1 ? _pageCount - 1 : 1,
                  label: '$_currentPage',
                  onChanged: (val) {
                    _pdfViewerController.jumpToPage(val.toInt());
                  },
                ),
              ),

              // Next Page
              IconButton(
                icon: const Icon(Icons.arrow_forward_ios_rounded, size: 18),
                tooltip: 'Next Page',
                onPressed: _currentPage < _pageCount
                    ? () => _pdfViewerController.nextPage()
                    : null,
              ),

              const SizedBox(width: 4),

              // Jump Button
              ElevatedButton(
                onPressed: _showJumpToPageDialog,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  visualDensity: VisualDensity.compact,
                ),
                child: Text('$_currentPage/$_pageCount'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
