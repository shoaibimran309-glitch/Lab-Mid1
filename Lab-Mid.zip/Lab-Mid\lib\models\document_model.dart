import 'dart:io';

/// Model representing a PDF Document stored in the local SQLite database.
/// Maps directly to the 'documents' table.
class DocumentModel {
  final int? id;
  final String title;
  final String filePath;
  final int fileSize; // in bytes
  final int pageCount;
  final DateTime createdAt;
  final DateTime lastOpened;
  final bool isFavorite;
  final String tags; // Comma-separated tags (e.g. "Work, Study, Invoices")
  final String description;
  final int lastReadPage;
  final double readingProgress; // 0.0 to 1.0 (0% to 100%)

  DocumentModel({
    this.id,
    required this.title,
    required this.filePath,
    required this.fileSize,
    required this.pageCount,
    required this.createdAt,
    required this.lastOpened,
    this.isFavorite = false,
    this.tags = '',
    this.description = '',
    this.lastReadPage = 1,
    this.readingProgress = 0.0,
  });

  /// Check if the physical file actually exists on storage
  bool get fileExists => File(filePath).existsSync();

  /// Formatted file size string (e.g., "2.4 MB", "512 KB")
  String get formattedFileSize {
    if (fileSize < 1024) return '$fileSize B';
    if (fileSize < 1024 * 1024) return '${(fileSize / 1024).toStringAsFixed(1)} KB';
    return '${(fileSize / (1024 * 1024)).toStringAsFixed(2)} MB';
  }

  /// Formatted progress percentage (e.g., "45%")
  String get progressPercentageString {
    final pct = (readingProgress * 100).clamp(0.0, 100.0);
    return '${pct.toInt()}%';
  }

  /// List of individual tag strings
  List<String> get tagList {
    if (tags.trim().isEmpty) return [];
    return tags.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
  }

  /// Create a copy with modified fields
  DocumentModel copyWith({
    int? id,
    String? title,
    String? filePath,
    int? fileSize,
    int? pageCount,
    DateTime? createdAt,
    DateTime? lastOpened,
    bool? isFavorite,
    String? tags,
    String? description,
    int? lastReadPage,
    double? readingProgress,
  }) {
    return DocumentModel(
      id: id ?? this.id,
      title: title ?? this.title,
      filePath: filePath ?? this.filePath,
      fileSize: fileSize ?? this.fileSize,
      pageCount: pageCount ?? this.pageCount,
      createdAt: createdAt ?? this.createdAt,
      lastOpened: lastOpened ?? this.lastOpened,
      isFavorite: isFavorite ?? this.isFavorite,
      tags: tags ?? this.tags,
      description: description ?? this.description,
      lastReadPage: lastReadPage ?? this.lastReadPage,
      readingProgress: readingProgress ?? this.readingProgress,
    );
  }

  /// Convert to SQLite Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'file_path': filePath,
      'file_size': fileSize,
      'page_count': pageCount,
      'created_at': createdAt.toIso8601String(),
      'last_opened': lastOpened.toIso8601String(),
      'is_favorite': isFavorite ? 1 : 0,
      'tags': tags,
      'description': description,
      'last_read_page': lastReadPage,
      'reading_progress': readingProgress,
    };
  }

  /// Create from SQLite Map
  factory DocumentModel.fromMap(Map<String, dynamic> map) {
    return DocumentModel(
      id: map['id'] as int?,
      title: map['title'] as String? ?? 'Untitled Document',
      filePath: map['file_path'] as String? ?? '',
      fileSize: (map['file_size'] as num?)?.toInt() ?? 0,
      pageCount: (map['page_count'] as num?)?.toInt() ?? 1,
      createdAt: map['created_at'] != null 
          ? DateTime.tryParse(map['created_at'] as String) ?? DateTime.now() 
          : DateTime.now(),
      lastOpened: map['last_opened'] != null 
          ? DateTime.tryParse(map['last_opened'] as String) ?? DateTime.now() 
          : DateTime.now(),
      isFavorite: (map['is_favorite'] as int? ?? 0) == 1,
      tags: map['tags'] as String? ?? '',
      description: map['description'] as String? ?? '',
      lastReadPage: (map['last_read_page'] as num?)?.toInt() ?? 1,
      readingProgress: (map['reading_progress'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
