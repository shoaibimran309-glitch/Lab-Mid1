import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import '../services/export_service.dart';

class ExportView extends StatefulWidget {
  const ExportView({Key? key}) : super(key: key);

  @override
  State<ExportView> createState() => _ExportViewState();
}

class _ExportViewState extends State<ExportView> {
  bool _isExporting = false;
  String _statusMessage = '';

  Future<void> _exportCsv({bool shareDirectly = false}) async {
    setState(() {
      _isExporting = true;
      _statusMessage = 'Generating CSV file with metadata, bookmarks, and history...';
    });

    try {
      final file = await ExportService.exportDataToCsv();
      if (!mounted) return;

      if (shareDirectly) {
        await ExportService.shareFile(
          file,
          text: 'PDF Reader Document Metadata & Reading History CSV Export',
          subject: 'PDF Reader Data Export (CSV)',
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('CSV Export saved to: ${file.path}'),
            action: SnackBarAction(
              label: 'Share',
              onPressed: () => ExportService.shareFile(file),
            ),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('CSV Export failed: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _exportPdfReport({bool printDirectly = false}) async {
    setState(() {
      _isExporting = true;
      _statusMessage = 'Compiling analytical PDF summary report...';
    });

    try {
      final file = await ExportService.generateSummaryPdfReport();
      if (!mounted) return;

      if (printDirectly) {
        final bytes = await file.readAsBytes();
        await Printing.layoutPdf(
          onLayout: (format) async => bytes,
          name: 'PDF_Reader_Reading_Report',
        );
      } else {
        await ExportService.shareFile(
          file,
          text: 'Comprehensive PDF Reader & Utility Reading Analytics Report',
          subject: 'PDF Reader Analytics Report',
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('PDF Report generation failed: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _sendViaEmail() async {
    setState(() {
      _isExporting = true;
      _statusMessage = 'Preparing data report for email attachment...';
    });

    try {
      final file = await ExportService.exportDataToCsv();
      if (!mounted) return;
      await ExportService.shareViaEmail(
        file,
        subject: 'PDF Reader & Utility: Document Metadata & History',
        body: 'Hello,\n\nPlease find attached the complete export of document metadata, reading sessions history, and page bookmarks from the PDF Reader application.\n\nRegards,\nPDF Reader Suite',
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Email sharing failed: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Export & Reports'),
      ),
      body: _isExporting
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  Text(_statusMessage, textAlign: TextAlign.center),
                ],
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // Top Info Banner
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: theme.colorScheme.primary.withOpacity(0.2)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline_rounded, color: theme.colorScheme.primary, size: 28),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Text(
                          'Export your document metadata, reading timeline, and bookmarks to standard formats (CSV, PDF report, or email).',
                          style: TextStyle(fontSize: 13, height: 1.4),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // OPTION 1: CSV EXPORT
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: Colors.green.shade50,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(Icons.table_chart_rounded, color: Colors.green),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Export to CSV Spreadsheet',
                                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 2),
                                  const Text(
                                    'RFC 4180 standard spreadsheet compatible with Microsoft Excel and Google Sheets.',
                                    style: TextStyle(fontSize: 12, color: Colors.grey),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () => _exportCsv(shareDirectly: false),
                                icon: const Icon(Icons.save_alt_rounded),
                                label: const Text('Save CSV'),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: () => _exportCsv(shareDirectly: true),
                                icon: const Icon(Icons.share_rounded),
                                label: const Text('Share CSV'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // OPTION 2: PDF REPORT
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: Colors.red.shade50,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(Icons.picture_as_pdf_rounded, color: Colors.red),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Generate Analytical PDF Report',
                                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 2),
                                  const Text(
                                    'Printable document with statistics, tables of documents read, and bookmark notes.',
                                    style: TextStyle(fontSize: 12, color: Colors.grey),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: () => _exportPdfReport(printDirectly: true),
                                icon: const Icon(Icons.print_rounded),
                                label: const Text('Preview / Print'),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: () => _exportPdfReport(printDirectly: false),
                                icon: const Icon(Icons.send_rounded),
                                label: const Text('Share Report'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // OPTION 3: EMAIL EXPORT
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: Colors.blue.shade50,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(Icons.email_outlined, color: Colors.blue),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Email Export Package',
                                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 2),
                                  const Text(
                                    'Directly launch email client with exported reading logs and document data attached.',
                                    style: TextStyle(fontSize: 12, color: Colors.grey),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: _sendViaEmail,
                            icon: const Icon(Icons.mail_rounded),
                            label: const Text('Compose Email with Export Attachment'),
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
