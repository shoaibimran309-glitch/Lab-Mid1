import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/document_model.dart';
import '../providers/document_provider.dart';
import '../widgets/reading_progress_bar.dart';
import '../widgets/edit_metadata_dialog.dart';
import '../services/export_service.dart';
import '../views/pdf_reader_view.dart';
import '../views/pdf_to_image_view.dart';

class DocumentCard extends StatelessWidget {
  final DocumentModel document;
  final bool isGrid;

  const DocumentCard({
    Key? key,
    required this.document,
    this.isGrid = false,
  }) : super(key: key);

  void _openReader(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PdfReaderView(document: document),
      ),
    );
  }

  void _showDeleteDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Document?'),
        content: Text('Are you sure you want to delete "${document.title}" from your library and storage?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              context.read<DocumentProvider>().deleteDocument(document);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Deleted "${document.title}"')),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final dateFormatted = DateFormat('MMM d, yyyy').format(document.lastOpened);

    if (isGrid) {
      return Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => _openReader(context),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Top row: PDF Badge + Favorite Heart
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.red.shade50,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.picture_as_pdf, color: Colors.red.shade700, size: 16),
                          const SizedBox(width: 4),
                          Text(
                            'PDF',
                            style: TextStyle(
                              color: Colors.red.shade700,
                              fontWeight: FontWeight.bold,
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                        document.isFavorite ? Icons.favorite : Icons.favorite_border,
                        color: document.isFavorite ? Colors.red : Colors.grey,
                        size: 20,
                      ),
                      onPressed: () => context.read<DocumentProvider>().toggleFavorite(document),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                // Title
                Expanded(
                  child: Text(
                    document.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                ),
                const SizedBox(height: 6),

                // Tags
                if (document.tagList.isNotEmpty)
                  Text(
                    '#${document.tagList.first}',
                    style: TextStyle(fontSize: 10, color: theme.colorScheme.primary, fontWeight: FontWeight.w600),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                const SizedBox(height: 8),

                // Reading Progress Bar
                ReadingProgressBar(
                  progress: document.readingProgress,
                  showText: true,
                  height: 4,
                ),
                const SizedBox(height: 6),

                // Page info
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Page ${document.lastReadPage}/${document.pageCount}',
                      style: TextStyle(fontSize: 10, color: Colors.grey.shade600),
                    ),
                    Text(
                      document.formattedFileSize,
                      style: TextStyle(fontSize: 10, color: Colors.grey.shade500),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    }

    // LIST VIEW CARD
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () => _openReader(context),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // PDF Icon Thumbnail Box
                  Container(
                    width: 52,
                    height: 58,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.red.shade700, Colors.red.shade900],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.red.withOpacity(0.2),
                          blurRadius: 6,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        const Icon(Icons.picture_as_pdf, color: Colors.white, size: 28),
                        Positioned(
                          bottom: 3,
                          child: Text(
                            '${document.pageCount}p',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 14),

                  // Info block
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                document.title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Text(
                              '${document.formattedFileSize} • Last opened: $dateFormatted',
                              style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                        if (document.description.isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text(
                            document.description,
                            style: TextStyle(fontSize: 11, color: Colors.grey.shade700, fontStyle: FontStyle.italic),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ],
                    ),
                  ),

                  // Actions: Favorite + Menu
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(
                          document.isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: document.isFavorite ? Colors.red : Colors.grey,
                          size: 22,
                        ),
                        onPressed: () => context.read<DocumentProvider>().toggleFavorite(document),
                      ),
                      PopupMenuButton<String>(
                        icon: const Icon(Icons.more_vert, size: 20),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        onSelected: (value) async {
                          switch (value) {
                            case 'read':
                              _openReader(context);
                              break;
                            case 'edit':
                              showDialog(
                                context: context,
                                builder: (_) => EditMetadataDialog(document: document),
                              );
                              break;
                            case 'convert':
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => PdfToImageView(selectedDocument: document),
                                ),
                              );
                              break;
                            case 'share':
                              final file = File(document.filePath);
                              if (await file.exists()) {
                                await ExportService.shareFile(
                                  file,
                                  subject: document.title,
                                  text: 'Sharing "${document.title}" from PDF Reader & Utility',
                                );
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('File not found on storage')),
                                );
                              }
                              break;
                            case 'delete':
                              _showDeleteDialog(context);
                              break;
                          }
                        },
                        itemBuilder: (context) => [
                          const PopupMenuItem(
                            value: 'read',
                            child: Row(
                              children: [
                                Icon(Icons.chrome_reader_mode_outlined, size: 18),
                                SizedBox(width: 10),
                                Text('Read PDF'),
                              ],
                            ),
                          ),
                          const PopupMenuItem(
                            value: 'edit',
                            child: Row(
                              children: [
                                Icon(Icons.edit_outlined, size: 18),
                                SizedBox(width: 10),
                                Text('Edit Metadata / Tags'),
                              ],
                            ),
                          ),
                          const PopupMenuItem(
                            value: 'convert',
                            child: Row(
                              children: [
                                Icon(Icons.image_outlined, size: 18),
                                SizedBox(width: 10),
                                Text('Convert to Images'),
                              ],
                            ),
                          ),
                          const PopupMenuItem(
                            value: 'share',
                            child: Row(
                              children: [
                                Icon(Icons.share_outlined, size: 18),
                                SizedBox(width: 10),
                                Text('Share File'),
                              ],
                            ),
                          ),
                          const PopupMenuDivider(),
                          const PopupMenuItem(
                            value: 'delete',
                            child: Row(
                              children: [
                                Icon(Icons.delete_outline, color: Colors.red, size: 18),
                                SizedBox(width: 10),
                                Text('Delete', style: TextStyle(color: Colors.red)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Tags chips row
              if (document.tagList.isNotEmpty) ...[
                Wrap(
                  spacing: 6,
                  children: document.tagList.map((tag) {
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.primary.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        '#$tag',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: theme.colorScheme.primary,
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 10),
              ],

              // Reading Progress Bar
              ReadingProgressBar(
                progress: document.readingProgress,
                showText: true,
                height: 5,
              ),
              const SizedBox(height: 6),

              // Page status and Resume button
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Page ${document.lastReadPage} of ${document.pageCount}',
                    style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                  ),
                  InkWell(
                    onTap: () => _openReader(context),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 4),
                      child: Row(
                        children: [
                          Text(
                            document.lastReadPage > 1 ? 'Resume Reading' : 'Start Reading',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: theme.colorScheme.primary,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Icon(Icons.arrow_forward, size: 14, color: theme.colorScheme.primary),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
