import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/pdf_service.dart';
import '../providers/document_provider.dart';
import 'pdf_reader_view.dart';

class ScannerView extends StatefulWidget {
  const ScannerView({Key? key}) : super(key: key);

  @override
  State<ScannerView> createState() => _ScannerViewState();
}

class _ScannerViewState extends State<ScannerView> {
  final List<File> _scannedPages = [];
  ScanFilter _selectedFilter = ScanFilter.original;
  bool _isProcessing = false;
  int _selectedPageIndex = 0;

  Future<void> _captureFromCamera() async {
    try {
      final image = await PdfService.captureImageFromCamera();
      if (image != null) {
        setState(() {
          _scannedPages.add(image);
          _selectedPageIndex = _scannedPages.length - 1;
        });
      }
    } catch (e) {
      _showErrorSnackBar('Failed to capture image: $e');
    }
  }

  Future<void> _pickFromGallery() async {
    try {
      final images = await PdfService.pickImagesFromGallery();
      if (images.isNotEmpty) {
        setState(() {
          _scannedPages.addAll(images);
          _selectedPageIndex = _scannedPages.length - 1;
        });
      }
    } catch (e) {
      _showErrorSnackBar('Failed to pick images: $e');
    }
  }

  void _removePage(int index) {
    setState(() {
      _scannedPages.removeAt(index);
      if (_selectedPageIndex >= _scannedPages.length && _scannedPages.isNotEmpty) {
        _selectedPageIndex = _scannedPages.length - 1;
      }
    });
  }

  void _showSaveDialog() {
    if (_scannedPages.isEmpty) return;

    final titleController = TextEditingController(
      text: 'Scan_${DateTime.now().year}${DateTime.now().month.toString().padLeft(2, '0')}${DateTime.now().day.toString().padLeft(2, '0')}_${DateTime.now().hour}${DateTime.now().minute}',
    );
    final tagsController = TextEditingController(text: 'Scanned, Assignment');
    final descController = TextEditingController(text: 'Document created via mobile scanner camera');

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.picture_as_pdf, color: Colors.red),
            SizedBox(width: 10),
            Text('Save as PDF Document'),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Document Title (${_scannedPages.length} Pages)', style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              TextField(
                controller: titleController,
                decoration: const InputDecoration(hintText: 'Enter document name'),
              ),
              const SizedBox(height: 14),
              const Text('Tags', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              TextField(
                controller: tagsController,
                decoration: const InputDecoration(hintText: 'e.g., Scanned, Receipt, Notes'),
              ),
              const SizedBox(height: 14),
              const Text('Description', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              TextField(
                controller: descController,
                maxLines: 2,
                decoration: const InputDecoration(hintText: 'Optional notes'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.of(ctx).pop();
              await _compileAndSavePdf(
                title: titleController.text,
                tags: tagsController.text,
                description: descController.text,
              );
            },
            child: const Text('Create PDF'),
          ),
        ],
      ),
    );
  }

  Future<void> _compileAndSavePdf({
    required String title,
    required String tags,
    required String description,
  }) async {
    setState(() => _isProcessing = true);

    try {
      final doc = await PdfService.createPdfFromImages(
        imageFiles: _scannedPages,
        title: title,
        tags: tags,
        description: description,
        filter: _selectedFilter,
      );

      if (!mounted) return;
      await context.read<DocumentProvider>().addScannedDocument(doc);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Successfully created "${doc.title}"!'),
          action: SnackBarAction(
            label: 'Open Now',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => PdfReaderView(document: doc)),
              );
            },
          ),
        ),
      );

      setState(() {
        _scannedPages.clear();
        _selectedPageIndex = 0;
      });
    } catch (e) {
      _showErrorSnackBar('Error compiling PDF: $e');
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Document Scanner'),
        actions: [
          if (_scannedPages.isNotEmpty)
            TextButton.icon(
              onPressed: _isProcessing ? null : _showSaveDialog,
              icon: const Icon(Icons.check_circle_rounded, color: Colors.green),
              label: const Text('Save PDF', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
            ),
        ],
      ),
      body: _isProcessing
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Compiling pages into PDF document...'),
                ],
              ),
            )
          : Column(
              children: [
                // Filter Enhancement Toolbar
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  color: theme.colorScheme.surface,
                  child: Row(
                    children: [
                      const Text('Filter: ', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(width: 8),
                      ChoiceChip(
                        label: const Text('Color'),
                        selected: _selectedFilter == ScanFilter.original,
                        onSelected: (val) => setState(() => _selectedFilter = ScanFilter.original),
                      ),
                      const SizedBox(width: 6),
                      ChoiceChip(
                        label: const Text('Grayscale'),
                        selected: _selectedFilter == ScanFilter.grayscale,
                        onSelected: (val) => setState(() => _selectedFilter = ScanFilter.grayscale),
                      ),
                      const SizedBox(width: 6),
                      ChoiceChip(
                        label: const Text('B&W Doc'),
                        selected: _selectedFilter == ScanFilter.blackAndWhite,
                        onSelected: (val) => setState(() => _selectedFilter = ScanFilter.blackAndWhite),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),

                // Main Preview Canvas
                Expanded(
                  child: _scannedPages.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(28),
                                decoration: BoxDecoration(
                                  color: Colors.blue.withOpacity(0.08),
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(
                                  Icons.document_scanner_rounded,
                                  size: 72,
                                  color: Colors.blue,
                                ),
                              ),
                              const SizedBox(height: 20),
                              const Text(
                                'Scan Multi-Page Documents',
                                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 8),
                              const Padding(
                                padding: EdgeInsets.symmetric(horizontal: 40),
                                child: Text(
                                  'Capture pages one by one using device camera or import from your photo gallery. Enhance with filters and export to standard PDF.',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(color: Colors.grey, height: 1.4),
                                ),
                              ),
                              const SizedBox(height: 28),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ElevatedButton.icon(
                                    onPressed: _captureFromCamera,
                                    icon: const Icon(Icons.camera_alt),
                                    label: const Text('Open Camera'),
                                    style: ElevatedButton.styleFrom(
                                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  OutlinedButton.icon(
                                    onPressed: _pickFromGallery,
                                    icon: const Icon(Icons.photo_library),
                                    label: const Text('Gallery'),
                                    style: OutlinedButton.styleFrom(
                                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        )
                      : Container(
                          padding: const EdgeInsets.all(16),
                          color: Colors.black.withOpacity(0.04),
                          child: Center(
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: Image.file(
                                    _scannedPages[_selectedPageIndex],
                                    fit: BoxFit.contain,
                                  ),
                                ),
                                Positioned(
                                  top: 10,
                                  right: 10,
                                  child: CircleAvatar(
                                    backgroundColor: Colors.black54,
                                    child: IconButton(
                                      icon: const Icon(Icons.delete, color: Colors.white, size: 20),
                                      onPressed: () => _removePage(_selectedPageIndex),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                ),

                // Bottom Page Tray & Capture controls (when pages exist)
                if (_scannedPages.isNotEmpty) ...[
                  Container(
                    height: 100,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    color: theme.colorScheme.surface,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: _scannedPages.length + 1,
                      itemBuilder: (ctx, idx) {
                        if (idx == _scannedPages.length) {
                          // "Add page" button in tray
                          return Center(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: OutlinedButton.icon(
                                onPressed: _captureFromCamera,
                                icon: const Icon(Icons.add_a_photo, size: 18),
                                label: const Text('Add Page'),
                              ),
                            ),
                          );
                        }

                        final isSelected = idx == _selectedPageIndex;
                        return GestureDetector(
                          onTap: () => setState(() => _selectedPageIndex = idx),
                          child: Container(
                            width: 65,
                            margin: const EdgeInsets.only(right: 10),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: isSelected ? theme.colorScheme.primary : Colors.grey.shade300,
                                width: isSelected ? 3 : 1,
                              ),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(6),
                                  child: Image.file(_scannedPages[idx], fit: BoxFit.cover),
                                ),
                                Positioned(
                                  bottom: 2,
                                  left: 2,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                    decoration: BoxDecoration(
                                      color: Colors.black87,
                                      borderRadius: BorderRadius.circular(4),
                                    ),
                                    child: Text(
                                      '${idx + 1}',
                                      style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ],
            ),
    );
  }
}
