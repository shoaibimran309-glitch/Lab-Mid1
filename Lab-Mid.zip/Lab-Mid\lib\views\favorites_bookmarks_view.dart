import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/document_provider.dart';
import '../providers/reader_provider.dart';
import '../widgets/document_card.dart';
import '../widgets/empty_state_widget.dart';
import '../models/bookmark_model.dart';
import 'pdf_reader_view.dart';

class FavoritesBookmarksView extends StatefulWidget {
  const FavoritesBookmarksView({Key? key}) : super(key: key);

  @override
  State<FavoritesBookmarksView> createState() => _FavoritesBookmarksViewState();
}

class _FavoritesBookmarksViewState extends State<FavoritesBookmarksView>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ReaderProvider>().loadAllBookmarks();
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _jumpToBookmarkedPage(BuildContext context, BookmarkModel bookmark) {
    final docProvider = context.read<DocumentProvider>();
    final matchedDoc = docProvider.documents.firstWhere(
      (d) => d.id == bookmark.documentId,
      orElse: () => docProvider.documents.isNotEmpty
          ? docProvider.documents.first
          : throw Exception('Document not found'),
    );

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PdfReaderView(
          document: matchedDoc,
          initialPage: bookmark.pageNumber,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final docProvider = context.watch<DocumentProvider>();
    final readerProvider = context.watch<ReaderProvider>();
    final favoriteDocs = docProvider.favoriteDocuments;
    final bookmarks = readerProvider.allBookmarks;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Favorites & Bookmarks'),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(
              icon: const Icon(Icons.favorite, size: 20),
              text: 'Starred PDFs (${favoriteDocs.length})',
            ),
            Tab(
              icon: const Icon(Icons.bookmark, size: 20),
              text: 'Page Bookmarks (${bookmarks.length})',
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // TAB 1: FAVORITE DOCUMENTS
          favoriteDocs.isEmpty
              ? const EmptyStateWidget(
                  icon: Icons.favorite_border,
                  title: 'No Favorite Documents Yet',
                  message: 'Tap the heart icon on any document in your library to add it to your favorites for quick access.',
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: favoriteDocs.length,
                  itemBuilder: (ctx, idx) => DocumentCard(
                    document: favoriteDocs[idx],
                    isGrid: false,
                  ),
                ),

          // TAB 2: PAGE BOOKMARKS
          bookmarks.isEmpty
              ? const EmptyStateWidget(
                  icon: Icons.bookmark_border,
                  title: 'No Bookmarked Pages',
                  message: 'When reading a PDF, tap the bookmark ribbon icon at the top to save specific pages and notes here.',
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: bookmarks.length,
                  itemBuilder: (ctx, idx) {
                    final bm = bookmarks[idx];
                    final dateStr = DateFormat('MMM d, yyyy • h:mm a').format(bm.createdAt);

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          children: [
                            // Page number badge
                            Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'P.',
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      color: Theme.of(context).colorScheme.primary,
                                    ),
                                  ),
                                  Text(
                                    '${bm.pageNumber}',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Theme.of(context).colorScheme.primary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 14),

                            // Details
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    bm.documentTitle.isNotEmpty
                                        ? bm.documentTitle
                                        : 'Document #${bm.documentId}',
                                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    bm.note.isNotEmpty ? bm.note : 'Bookmark on page ${bm.pageNumber}',
                                    style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    dateStr,
                                    style: TextStyle(fontSize: 10, color: Colors.grey.shade500),
                                  ),
                                ],
                              ),
                            ),

                            // Actions: Jump & Delete
                            IconButton(
                              icon: const Icon(Icons.arrow_circle_right_outlined, color: Colors.blue),
                              tooltip: 'Jump to Page',
                              onPressed: () => _jumpToBookmarkedPage(context, bm),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete_outline, color: Colors.redAccent, size: 20),
                              tooltip: 'Remove Bookmark',
                              onPressed: () {
                                if (bm.id != null) {
                                  context.read<ReaderProvider>().deleteBookmark(bm.id!);
                                }
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ],
      ),
    );
  }
}
