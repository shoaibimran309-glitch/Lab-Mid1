/// Model representing a reading session or history log entry.
/// Maps directly to the 'reading_history' table in SQLite.
class ReadingHistoryModel {
  final int? id;
  final int documentId;
  final String documentTitle;
  final int pageNumber;
  final int totalPages;
  final double progressPercentage;
  final DateTime timestamp;

  ReadingHistoryModel({
    this.id,
    required this.documentId,
    required this.documentTitle,
    required this.pageNumber,
    required this.totalPages,
    required this.progressPercentage,
    required this.timestamp,
  });

  String get formattedProgress => '${(progressPercentage * 100).toInt()}%';

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'document_id': documentId,
      'document_title': documentTitle,
      'page_number': pageNumber,
      'total_pages': totalPages,
      'progress_percentage': progressPercentage,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  factory ReadingHistoryModel.fromMap(Map<String, dynamic> map) {
    return ReadingHistoryModel(
      id: map['id'] as int?,
      documentId: (map['document_id'] as num?)?.toInt() ?? 0,
      documentTitle: map['document_title'] as String? ?? 'Document',
      pageNumber: (map['page_number'] as num?)?.toInt() ?? 1,
      totalPages: (map['total_pages'] as num?)?.toInt() ?? 1,
      progressPercentage: (map['progress_percentage'] as num?)?.toDouble() ?? 0.0,
      timestamp: map['timestamp'] != null 
          ? DateTime.tryParse(map['timestamp'] as String) ?? DateTime.now() 
          : DateTime.now(),
    );
  }
}
