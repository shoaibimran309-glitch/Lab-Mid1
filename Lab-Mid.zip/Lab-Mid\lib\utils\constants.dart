import 'package:flutter/material.dart';

class AppConstants {
  static const String appName = 'PDF Reader & Utility';
  static const String appVersion = '1.0.0 (Lab-Mid)';

  // Database Constants
  static const String dbName = 'pdf_reader_utility.db';
  static const int dbVersion = 1;

  // Tables
  static const String tableDocuments = 'documents';
  static const String tableBookmarks = 'bookmarks';
  static const String tableReadingHistory = 'reading_history';
  static const String tablePreferences = 'user_preferences';

  // Reading Background Colors
  static const List<ReadingBackgroundColor> readingBgColors = [
    ReadingBackgroundColor(
      name: 'Default White',
      color: Colors.white,
      textColor: Colors.black87,
      value: 0xFFFFFFFF,
    ),
    ReadingBackgroundColor(
      name: 'Parchment Sepia',
      color: Color(0xFFFBF0D9),
      textColor: Color(0xFF3E2723),
      value: 0xFFFBF0D9,
    ),
    ReadingBackgroundColor(
      name: 'Night Charcoal',
      color: Color(0xFF1E1E1E),
      textColor: Color(0xFFE0E0E0),
      value: 0xFF1E1E1E,
    ),
    ReadingBackgroundColor(
      name: 'Mint Serenity',
      color: Color(0xFFE8F5E9),
      textColor: Color(0xFF1B5E20),
      value: 0xFFE8F5E9,
    ),
    ReadingBackgroundColor(
      name: 'Warm Cream',
      color: Color(0xFFFFF9E6),
      textColor: Color(0xFF4E342E),
      value: 0xFFFFF9E6,
    ),
  ];

  // Default Tags
  static const List<String> defaultTags = [
    'All',
    'Course',
    'Midterm',
    'Assignment',
    'Books',
    'Research',
    'Personal',
  ];

  // Notification Sound Options
  static const List<String> notificationSounds = [
    'default',
    'chime',
    'bell',
    'subtle',
  ];
}

class ReadingBackgroundColor {
  final String name;
  final Color color;
  final Color textColor;
  final int value;

  const ReadingBackgroundColor({
    required this.name,
    required this.color,
    required this.textColor,
    required this.value,
  });
}
