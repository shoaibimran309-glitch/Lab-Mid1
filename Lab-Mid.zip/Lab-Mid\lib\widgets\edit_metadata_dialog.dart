import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/document_model.dart';
import '../providers/document_provider.dart';
import '../utils/constants.dart';

class EditMetadataDialog extends StatefulWidget {
  final DocumentModel document;

  const EditMetadataDialog({Key? key, required this.document}) : super(key: key);

  @override
  State<EditMetadataDialog> createState() => _EditMetadataDialogState();
}

class _EditMetadataDialogState extends State<EditMetadataDialog> {
  late TextEditingController _titleController;
  late TextEditingController _tagsController;
  late TextEditingController _descriptionController;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.document.title);
    _tagsController = TextEditingController(text: widget.document.tags);
    _descriptionController = TextEditingController(text: widget.document.description);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _tagsController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  void _addTag(String tag) {
    final current = _tagsController.text.trim();
    if (current.isEmpty) {
      _tagsController.text = tag;
    } else {
      final existingTags = current.split(',').map((e) => e.trim()).toList();
      if (!existingTags.contains(tag)) {
        _tagsController.text = '$current, $tag';
      }
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 500),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.edit_note_rounded, color: theme.colorScheme.primary, size: 28),
                    const SizedBox(width: 12),
                    Text(
                      'Edit Document Metadata',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Title Field
                Text('Document Title', style: TextStyle(fontWeight: FontWeight.w600, color: theme.colorScheme.onSurface)),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(
                    hintText: 'Enter document title',
                    prefixIcon: Icon(Icons.title_rounded),
                  ),
                  validator: (val) {
                    if (val == null || val.trim().isEmpty) {
                      return 'Please enter a valid title';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Tags Field
                Text('Tags (comma separated)', style: TextStyle(fontWeight: FontWeight.w600, color: theme.colorScheme.onSurface)),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _tagsController,
                  decoration: const InputDecoration(
                    hintText: 'e.g. Course, Midterm, Notes',
                    prefixIcon: Icon(Icons.local_offer_outlined),
                  ),
                ),
                const SizedBox(height: 8),

                // Preset Tag Chips
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: AppConstants.defaultTags
                      .where((t) => t != 'All')
                      .map((tag) => ActionChip(
                            label: Text(tag, style: const TextStyle(fontSize: 11)),
                            avatar: const Icon(Icons.add, size: 14),
                            visualDensity: VisualDensity.compact,
                            onPressed: () => _addTag(tag),
                          ))
                      .toList(),
                ),
                const SizedBox(height: 16),

                // Description Field
                Text('Description / Notes', style: TextStyle(fontWeight: FontWeight.w600, color: theme.colorScheme.onSurface)),
                const SizedBox(height: 6),
                TextFormField(
                  controller: _descriptionController,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    hintText: 'Add an optional description or notes about this document...',
                    prefixIcon: Icon(Icons.notes_rounded),
                  ),
                ),
                const SizedBox(height: 24),

                // Action Buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Cancel'),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      onPressed: () async {
                        if (_formKey.currentState!.validate()) {
                          if (widget.document.id != null) {
                            await context.read<DocumentProvider>().updateMetadata(
                                  id: widget.document.id!,
                                  title: _titleController.text.trim(),
                                  tags: _tagsController.text.trim(),
                                  description: _descriptionController.text.trim(),
                                );
                          }
                          if (mounted) Navigator.of(context).pop();
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      ),
                      child: const Text('Save Changes'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
